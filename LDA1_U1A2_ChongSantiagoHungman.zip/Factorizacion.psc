Algoritmo  FACTORIZACI�N
    Definir num Como Real
	Definir factorizar Como Logico
	Leer num
    Escribir "Ingrese el numero: "
    Escribir "Factorizacion: "
    
    factorizar<-verdadero
    
    Mientras factorizar Y num>1 hacer
        div<-0
        Si num/2 = trunc(num/2) Entonces
            Escribir 2
            num<-num/2
        Sino
            div<-1; factor_primo<-Verdadero
            Mientras div<=rc(num) Y factor_primo Hacer
                div <- div+2
                Si num/div = trunc(num/div) Entonces
                    factor_primo <- Falso
                FinSi
            FinMientras
            Si factor_primo Entonces
                escribir num
                factorizar<-falso
            sino
                escribir div
                num<-num/div
                factor_primo<-verdadero
            FinSi
        FinSi
    FinMientras
    
FinProceso

